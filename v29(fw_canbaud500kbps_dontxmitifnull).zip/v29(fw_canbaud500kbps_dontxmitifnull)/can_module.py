from __future__ import print_function
import can
import threading
import time
from func_table import *

bus = None
def initBus():
    global bus
    
    bus = can.interface.Bus(bustype='seeedstudio', channel='COM7', baudrate=2000000, timeout=0.1, frame_type='STD', operation_mode='normal', bitrate=500000)
    #Delay for safe timing between threads
    time.sleep(0.1)
    
    return bus

def shutdownBus():
    global bus
    
    #Closes COM port
    bus.shutdown()
    #Delay for safe timing between threads
    time.sleep(0.1)

def resetBus():
    shutdownBus()
    initBus()

def readMsg(bus):
    global func_table_idx
    can_data_tx = [0]*8

    #Pack CAN message
    can_data_tx = packCanDataTx(can_data_tx, 0x01, incrCanFuncTable(), 0x0000)

    can_msg_tx = can.Message(arbitration_id=0x00000001, data=can_data_tx, is_extended_id=False)
    print('Message sent:', can_msg_tx)
    bus.send(can_msg_tx)
    can_msg_rx = bus.recv(0.5) #0.5 magic number
    print('Message received:', can_msg_rx)

    return can_msg_rx

def writeMsg(bus, func, value):
    can_data_tx = [0]*8

    #Pack CAN message
    can_data_tx = packCanDataTx(can_data_tx, 0x00, func, value)

    can_msg_tx = can.Message(arbitration_id=0x00000001, data=can_data_tx, is_extended_id=False)
    print('Message sent:', can_msg_tx)
    bus.send(can_msg_tx)
    can_msg_rx = bus.recv(0.5) #0.5 magic number
    print('Message received:', can_msg_rx)

    return can_msg_rx

def packCanDataTx(can_data_tx, wr, func, value): #todo: remove first arg
    can_data_tx[0] = wr
    can_data_tx[1] = func & 0xFF
    can_data_tx[2] = (func>>8) & 0xFF
    can_data_tx[3] = value & 0xFF
    can_data_tx[4] = (value>>8) & 0xFF
    can_data_tx[5] = 0x00
    can_data_tx[6] = 0x00

    #Calculate checksum for can_data_tx
    can_data_tx[7] = 0x00 
    for i in range(0, 7):
        can_data_tx[7] = can_data_tx[7]^can_data_tx[i]
            
    return can_data_tx

def unpackMsg(can_msg_rx):
    can_data_rx = [0]*8
    
    if(can_msg_rx != None):
    #Unpack can_msg_rx
        for i in range(0, 8):
            can_data_rx[i] = can_msg_rx.data[i]
            
    return can_data_rx

can_data_rx_verif = [0]*8
def verifyChecksumCanDataRx(can_data_rx):
    global can_data_rx_verif
    chksum_calc = 0x00
    
    for i in range(0, 7):
        chksum_calc = chksum_calc^can_data_rx[i]

    if(chksum_calc == can_data_rx[7]):
        can_data_rx_verif = can_data_rx
    else:
        checkErrorCanDataRx(can_data_rx)
        print('Checksum error in can_data_rx')

def updateFuncTable():
    global can_data_rx_verif
    
    func = can_data_rx_verif[1] | (can_data_rx_verif[2]<<8)
    value = can_data_rx_verif[3] | (can_data_rx_verif[4]<<8)
    print('func:', func, 'value:', value) #todo: to know why removing print slows down exec

    #Update func_table
    try:
        func_table[func][1] = value
    except:
        pass

    return func, value

def getCanDataRxValue(func):
    try:
        value = func_table[func][1]
    except:
        value = 0
    return value

def checkErrorCanDataRx(can_data_rx): #todo: non existing func shouldnt be here
    if(can_data_rx != None):
        if(can_data_rx[1]==0x99 and can_data_rx[2]==0x99):
            if(can_data_rx[3]==0x00):
                print('Checksum error in can_data_tx')
            elif(can_data_rx[3]==0x01):
                print('Function from can_data_tx does not exist')

func_table_idx = 0
def incrCanFuncTable():
    #return list(func_table.keys())[0]
    
    global func_table_idx
    
    func_table_idx += 1
    if func_table_idx > (len(func_table) - 1):
        func_table_idx = 0

    return list(func_table.keys())[func_table_idx]

can_listen_en = 0
def threadListenCan():
    global can_listen_en, bus

    bus = initBus()
    can_data_tx = [0]*8
    can_data_rx = [0]*8

    while True:
        if can_listen_en == 1:
            time.sleep(0.015) 
            #Read CAN message
            can_msg_rx = readMsg(bus) #0.5s timeout

            #When CAN message is received or timeout expires:
            #todo: add acknowledge before next read
            if(can_msg_rx == None):
                resetBus()

            #Unpack CAN message
            can_data_rx = unpackMsg(can_msg_rx)
            verifyChecksumCanDataRx(can_data_rx)
            updateFuncTable()
            #print('')
        else:
            time.sleep(0.1)

def processWriteMsg(func, value):
    global bus

    setCanListenEn(0)
    resetBus()
    
    can_data_tx = [0]*8
    can_data_rx = [0]*8
    
    setCanListenEn(0)
    time.sleep(0.5)
    
    if getCanListenEn() == 0:
        #Write CAN message
        can_msg_rx = writeMsg(bus, func, value)
        if(can_msg_rx == None):
            resetBus()

        #Unpack CAN message
        can_data_rx = unpackMsg(can_msg_rx)
        verifyChecksumCanDataRx(can_data_rx)

    resetBus()
    setCanListenEn(1)
    
def setCanListenEn(x):
    global can_listen_en
    can_listen_en = x
    #Delay for safe timing between threads
    time.sleep(0.1)

def getCanListenEn():
    global can_listen_en
    return can_listen_en

'''
cnt_sawtooth = 0
def incrSawtooth():
    global cnt_sawtooth
    list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    if cnt_sawtooth > (len(list) - 2):
        cnt_sawtooth = 0
    else:
        cnt_sawtooth = cnt_sawtooth + 1
    
    return list[cnt_sawtooth]

cnt_dc100 = 0
def incrDc100():
    global cnt_dc100
    list = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110]
    
    if cnt_dc100 > (len(list) - 2):
        cnt_dc100 = 0
    else:
        cnt_dc100 = cnt_dc100 + 1
    
    return list[cnt_dc100]

cnt_dc200 = 0
def incrDc200():
    global cnt_dc200
    list = [201, 202, 203, 204, 205, 206, 207, 208, 209, 210]
    
    if cnt_dc200 > (len(list) - 2):
        cnt_dc200 = 0
    else:
        cnt_dc200 = cnt_dc200 + 1
    
    return list[cnt_dc200]

'''

if __name__ == '__main__':
    pass
    '''
    setCanListenEn(1)
    thread_listen_can = threading.Thread(target=threadListenCan)
    thread_listen_can.start()

    time.sleep(5)
    processWriteMsg(0x401, 0x6969)
    '''
