'''
Param Write/read format:
{func : func, value, watch, label, label_value, lineedit, pb, checkbox}
        [0    1      2      3      4            5         6   7]

Status
{func : func, value, watch, qwidget, label_value, dock, pb, checkbox}
        [0    1      2      3        4            5     6   7]
'''

#From CAN protocol doc
state_control =            [0x000, 0, 0, None, None, None, None, None]
state_calib =              [0x001, 0, 0, None, None, None, None, None]
state_hkeep =              [0x002, 0, 0, None, None, None, None, None]

status_control =           [0x100, 0, 0, None, None, None, None, None]
control_en =               [0x100, 0, 0, None, None, None, None, None]
dir_v2g =                  [0x100, 0, 0, None, None, None, None, None]
calib_ok =                 [0x100, 0, 0, None, None, None, None, None]
debug_en =                 [0x100, 0, 0, None, None, None, None, None]
eoss_llc1 =                [0x100, 0, 0, None, None, None, None, None]
eoss_llc2 =                [0x100, 0, 0, None, None, None, None, None]
llc2_en =                  [0x100, 0, 0, None, None, None, None, None]
pri_halfbridge_en =        [0x100, 0, 0, None, None, None, None, None]
config_ok =                [0x100, 0, 0, None, None, None, None, None]
debug_fault_en =           [0x100, 0, 0, None, None, None, None, None]
status_control_bitmap =    [control_en, dir_v2g, calib_ok, debug_en, eoss_llc1, eoss_llc2, llc2_en, pri_halfbridge_en, config_ok, debug_fault_en, None, None, None, None, None, None]

status_fault =             [0x101, 0, 0, None, None, None, None, None]
tz =                       [0x101, 0, 0, None, None, None, None, None]
vout_ov =                  [0x101, 0, 0, None, None, None, None, None]
vbat_ov =                  [0x101, 0, 0, None, None, None, None, None]
vbulk_ov =                 [0x101, 0, 0, None, None, None, None, None]
vaux_uv =                  [0x101, 0, 0, None, None, None, None, None]
llc1_sec_idc_oc =          [0x101, 0, 0, None, None, None, None, None]
llc2_sec_idc_oc =          [0x101, 0, 0, None, None, None, None, None]
llc1_pri_idc_oc =          [0x101, 0, 0, None, None, None, None, None]
llc2_pri_idc_oc =          [0x101, 0, 0, None, None, None, None, None]
llc1_temp_sr_ot =          [0x101, 0, 0, None, None, None, None, None]
llc2_temp_sr_ot =          [0x101, 0, 0, None, None, None, None, None]
temp_outlet_ot =           [0x101, 0, 0, None, None, None, None, None]
status_fault_bitmap =      [tz, vout_ov, vbat_ov, vbulk_ov, vaux_uv, llc1_sec_idc_oc, llc2_sec_idc_oc, llc1_pri_idc_oc, llc2_pri_idc_oc, llc1_temp_sr_ot, llc2_temp_sr_ot, temp_outlet_ot, None, None, None, None]

status_digin =             [0x102, 0, 0, None, None, None, None, None]
can_addr1 =                [0x102, 0, 0, None, None, None, None, None]
can_addr2 =                [0x102, 0, 0, None, None, None, None, None]
can_addr3 =                [0x102, 0, 0, None, None, None, None, None]
can_addr4 =                [0x102, 0, 0, None, None, None, None, None]
pfc_ok =                   [0x102, 0, 0, None, None, None, None, None]
ac_ok =                    [0x102, 0, 0, None, None, None, None, None]
dcdc_en =                  [0x102, 0, 0, None, None, None, None, None]
status_digin_bitmap =      [can_addr1, can_addr2, can_addr3, can_addr4, pfc_ok, ac_ok, dcdc_en, None, None, None, None, None, None, None, None, None]

status_digout =            [0x103, 0, 0, None, None, None, None, None]
led_r =                    [0x103, 0, 0, None, None, None, None, None]
led_g =                    [0x103, 0, 0, None, None, None, None, None]
led_y =                    [0x103, 0, 0, None, None, None, None, None]
dchg_off =                 [0x103, 0, 0, None, None, None, None, None]
pfc_en =                   [0x103, 0, 0, None, None, None, None, None]
temp_mux_s0 =              [0x103, 0, 0, None, None, None, None, None]
temp_mux_s1 =              [0x103, 0, 0, None, None, None, None, None]
temp_mux_s2 =              [0x103, 0, 0, None, None, None, None, None]
valve_en =                 [0x103, 0, 0, None, None, None, None, None]
relay_en =                 [0x103, 0, 0, None, None, None, None, None]
status_digout_bitmap =     [led_r, led_g, led_y, dchg_off, pfc_en, temp_mux_s0, temp_mux_s1, temp_mux_s2, valve_en, relay_en, None, None, None, None, None, None]

llc1_sec_idc =             [0x200, 0, 0, None, None, None, None, None]
llc1_pri_idc =             [0x201, 0, 0, None, None, None, None, None]
vout =                     [0x202, 0, 0, None, None, None, None, None]
vbat =                     [0x203, 0, 0, None, None, None, None, None]
vaux =                     [0x204, 0, 0, None, None, None, None, None]
vbulk =                    [0x205, 0, 0, None, None, None, None, None]
llc2_pri_idc =             [0x206, 0, 0, None, None, None, None, None]
llc2_sec_idc =             [0x207, 0, 0, None, None, None, None, None]
llc1_temp_sr =             [0x208, 0, 0, None, None, None, None, None]
llc2_temp_sr =             [0x209, 0, 0, None, None, None, None, None]
temp_outlet =              [0x20A, 0, 0, None, None, None, None, None]
gain_vout =                [0x20B, 0, 0, None, None, None, None, None]
offset_vout =              [0x20C, 0, 0, None, None, None, None, None]
gain_vbat =                [0x20D, 0, 0, None, None, None, None, None]
offset_vbat =              [0x20E, 0, 0, None, None, None, None, None]
gain_vbulk =               [0x20F, 0, 0, None, None, None, None, None]
offset_vbulk =             [0x210, 0, 0, None, None, None, None, None]
gain_llc1_sec_idc =        [0x211, 0, 0, None, None, None, None, None]
offset_llc1_sec_idc =      [0x212, 0, 0, None, None, None, None, None]

ref_vbat =                 [0x300, 0, 0, None, None, None, None, None]
ref_vbat_calib =           [0x301, 0, 0, None, None, None, None, None]
ref_iout =                 [0x302, 0, 0, None, None, None, None, None]
ref_iout_calib =           [0x303, 0, 0, None, None, None, None, None]
ref_iout_llc1_calib =      [0x304, 0, 0, None, None, None, None, None]
ref_iout_llc2_calib =      [0x305, 0, 0, None, None, None, None, None]
ref_vbulk_calib =          [0x306, 0, 0, None, None, None, None, None]
ref_vbulk_llc1_calib =     [0x307, 0, 0, None, None, None, None, None]
ref_vbulk_llc2_calib =     [0x308, 0, 0, None, None, None, None, None]
ref_pout =                 [0x309, 0, 0, None, None, None, None, None]
llc1_ts_tbctr =            [0x30A, 0, 0, None, None, None, None, None]
llc1_ps =                  [0x30B, 0, 0, None, None, None, None, None]
llc1_burstduty =           [0x30C, 0, 0, None, None, None, None, None]
llc2_ts_tbctr =            [0x30D, 0, 0, None, None, None, None, None]
llc2_ps =                  [0x30E, 0, 0, None, None, None, None, None]
llc2_burstduty =           [0x30F, 0, 0, None, None, None, None, None]
pfm_kp =                   [0x310, 0, 0, None, None, None, None, None]
pfm_ki =                   [0x311, 0, 0, None, None, None, None, None]
pfm_integ_max =            [0x312, 0, 0, None, None, None, None, None]
pfm_integ_min =            [0x313, 0, 0, None, None, None, None, None]
pspwm_kp =                 [0x314, 0, 0, None, None, None, None, None]
pspwm_ki =                 [0x315, 0, 0, None, None, None, None, None]
pspwm_integ_max =          [0x316, 0, 0, None, None, None, None, None]
pspwm_integ_min =          [0x317, 0, 0, None, None, None, None, None]
burstduty_kp =             [0x318, 0, 0, None, None, None, None, None]
burstduty_ki =             [0x319, 0, 0, None, None, None, None, None]
burstduty_integ_max =      [0x31A, 0, 0, None, None, None, None, None]
burstduty_integ_min =      [0x31B, 0, 0, None, None, None, None, None]
vdroop_kp =                [0x31C, 0, 0, None, None, None, None, None]
vdroop_ki =                [0x31D, 0, 0, None, None, None, None, None]
vdroop_integ_max =         [0x31E, 0, 0, None, None, None, None, None]
vdroop_integ_min =         [0x31F, 0, 0, None, None, None, None, None]

version =                  [0x400, 0, 0, None, None, None, None, None]
runtime_adca1 =            [0x401, 0, 0, None, None, None, None, None]
runtime_adcb1 =            [0x402, 0, 0, None, None, None, None, None]
runtime_control =          [0x403, 0, 0, None, None, None, None, None]
runtime_idle =             [0x404, 0, 0, None, None, None, None, None]
        
llc1_ts_tbctr_buffer =     [0x500, 0, 0, None, None, None, None, None]
llc1_ps_buffer =           [0x501, 0, 0, None, None, None, None, None]
llc1_burstduty_buffer =    [0x502, 0, 0, None, None, None, None, None]
llc2_ts_tbctr_buffer =     [0x503, 0, 0, None, None, None, None, None]
llc2_ps_buffer =           [0x504, 0, 0, None, None, None, None, None]
llc2_burstduty_buffer =    [0x505, 0, 0, None, None, None, None, None]

func_table = {
    0x0000 : state_control,
    0x0001 : state_calib,
    0x0002 : state_hkeep,
    0x0100 : status_control,
    0x0101 : status_fault,
    0x0102 : status_digin,
    0x0103 : status_digout,
    0x0200 : llc1_sec_idc,
    0x0201 : llc1_pri_idc,
    0x0202 : vout,
    0x0203 : vbat,
    0x0204 : vaux,
    0x0205 : vbulk,
    0x0206 : llc2_pri_idc,
    0x0207 : llc2_sec_idc,
    0x0208 : llc1_temp_sr,
    0x0209 : llc2_temp_sr,
    0x020A : temp_outlet,
    0x020B : gain_vout,
    0x020C : offset_vout,
    0x020D : gain_vbat,
    0x020E : offset_vbat,
    0x020F : gain_vbulk,
    0x0210 : offset_vbulk,
    0x0211 : gain_llc1_sec_idc,
    0x0212 : offset_llc1_sec_idc,
    0x0300 : ref_vbat,
    0x0301 : ref_vbat_calib,
    0x0302 : ref_iout,
    0x0303 : ref_iout_calib,
    0x0304 : ref_iout_llc1_calib,
    0x0305 : ref_iout_llc2_calib,
    0x0306 : ref_vbulk_calib,
    0x0307 : ref_vbulk_llc1_calib,
    0x0308 : ref_vbulk_llc2_calib,
    0x0309 : ref_pout,
    0x030A : llc1_ts_tbctr,
    0x030B : llc1_ps,
    0x030C : llc1_burstduty,
    0x030D : llc2_ts_tbctr,
    0x030E : llc2_ps,
    0x030F : llc2_burstduty,
    0x0310 : pfm_kp,
    0x0311 : pfm_ki,
    0x0312 : pfm_integ_max,
    0x0313 : pfm_integ_min,
    0x0314 : pspwm_kp,
    0x0315 : pspwm_ki,
    0x0316 : pspwm_integ_max,
    0x0317 : pspwm_integ_min,
    0x0318 : burstduty_kp,
    0x0319 : burstduty_ki,
    0x031A : burstduty_integ_max,
    0x031B : burstduty_integ_min,
    0x031C : vdroop_kp,
    0x031D : vdroop_ki,
    0x031E : vdroop_integ_max,
    0x031F : vdroop_integ_min,
    0x0400 : version,
    0x0401 : runtime_adca1,
    0x0402 : runtime_adcb1,
    0x0403 : runtime_control,
    0x0404 : runtime_idle,
    0x0500 : llc1_ts_tbctr_buffer,
    0x0501 : llc1_ps_buffer,
    0x0502 : llc1_burstduty_buffer,
    0x0503 : llc2_ts_tbctr_buffer,
    0x0504 : llc2_ps_buffer,
    0x0505 : llc2_burstduty_buffer  
}

def getSizeFuncTable():
    return len(func_table)

if __name__== '__main__':
    #print(len(func_table))
    #print(getSizeFuncTable())
    pass
