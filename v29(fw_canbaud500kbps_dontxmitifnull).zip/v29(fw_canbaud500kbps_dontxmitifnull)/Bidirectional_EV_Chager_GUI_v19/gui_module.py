from PyQt5 import QtCore
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QComboBox, QPushButton, QTabWidget, QWidget, QFormLayout, QLineEdit, QHBoxLayout, QRadioButton, QCheckBox, QVBoxLayout, QFrame, QGridLayout, QSizePolicy, QDockWidget
import sys
import serial.tools.list_ports
import can
import logging
import threading
import time
from plot_module import *
from func_table import *

watch_func = 0
def actCheckBox(var_array):
    global watch_func
    
    #var_array[3] = var_array[0].isChecked() #use in future for multiple waveforms
    watch_func = var_array[0] #use temporarily for 1 waveform

def actPushButton(var_array):
    global act_line_edit
    processWriteMsg(var_array[0], act_line_edit)
    var_array[5].clear()
    #window.updatePbListen(window)

def actPushButtonStatusControl(bitplace, value):
    if(value == 1):
        processWriteMsg(status_control[0], (1<<bitplace) | status_control[1])
    else:
        processWriteMsg(status_control[0], ~((1<<bitplace) | ~status_control[1]))

def actDock(var_array):
    var_array[5].setHidden(False)
    var_array[5].raise_()

act_line_edit = 0
def actLineEdit(text):
    global act_line_edit

    try:
        act_line_edit = int(text)
    except:
        act_line_edit = int(0)

def initParam(var_array, name):
#write/read: func, value, watch, label, label_value, lineedit, pb, checkbox    
    #label
    var_array[3] = QLabel(name)
    var_array[3].setFixedWidth(80)
    var_array[3].setFixedHeight(15)
    #label_value
    var_array[4] = QLabel('0')
    var_array[4].setFixedWidth(40)
    var_array[4].setFixedHeight(15)
    #lineedit
    var_array[5] = QLineEdit()
    var_array[5].setFixedWidth(40)
    var_array[5].setFixedHeight(15)
    var_array[5].setValidator(QIntValidator())
    var_array[5].textChanged.connect(actLineEdit)
    #pb
    var_array[6] = QPushButton()
    var_array[6].setFixedWidth(15)
    var_array[6].setFixedHeight(15)
    var_array[6].setStyleSheet('background-color: #000075; color: white')
    var_array[6].setText('⇒')
    var_array[6].clicked.connect(lambda: actPushButton(var_array))
    #checkbox
    var_array[7] = QCheckBox()
    var_array[7].setFixedWidth(15)
    var_array[7].setFixedHeight(15)
    var_array[7].toggle()
    var_array[7].setChecked(False)
    var_array[7].stateChanged.connect(lambda: actCheckBox(var_array))

def initStatusBit(var_array, bitplace, name):
#write/read: func, value, watch, label, label_value, pb0, pb1, checkbox    
    #label
    var_array[bitplace][3] = QLabel(name)
    var_array[bitplace][3].setFixedWidth(80)
    var_array[bitplace][3].setFixedHeight(15)
    #label_value
    var_array[bitplace][4] = QLabel('0')
    var_array[bitplace][4].setFixedWidth(40)
    var_array[bitplace][4].setFixedHeight(15)
    #pb0
    var_array[bitplace][5] = QPushButton()
    var_array[bitplace][5].setFixedWidth(15)
    var_array[bitplace][5].setFixedHeight(15)
    var_array[bitplace][5].setStyleSheet('background-color: #000075; color: white')
    var_array[bitplace][5].setText('0')
    var_array[bitplace][5].clicked.connect(lambda: actPushButtonStatusControl(bitplace, 0))
    #pb1
    var_array[bitplace][6] = QPushButton()
    var_array[bitplace][6].setFixedWidth(15)
    var_array[bitplace][6].setFixedHeight(15)
    var_array[bitplace][6].setStyleSheet('background-color: #000075; color: white')
    var_array[bitplace][6].setText('1')
    var_array[bitplace][6].clicked.connect(lambda: actPushButtonStatusControl(bitplace, 1))
    #checkbox
    var_array[bitplace][7] = QCheckBox()
    var_array[bitplace][7].setFixedWidth(15)
    var_array[bitplace][7].setFixedHeight(15)
    var_array[bitplace][7].toggle()
    var_array[bitplace][7].setChecked(False)
    var_array[bitplace][7].stateChanged.connect(lambda: actCheckBox(var_array)) #todo: 

def initStatusControl(var_array, var_array_bitmap, name):
#write/read: func, value, watch, qwidget, label_value, dock, pb, checkbox    
    #label_value
    var_array[4] = QLabel('0')
    var_array[4].setFixedWidth(40)
    var_array[4].setFixedHeight(15)
    #dock
    var_array[5] = QDockWidget(name)
    var_array[5].setGeometry(0, 0, 200, 300)

    var_array[3] = QWidget()
    var_array[3].layout =  QGridLayout()

    initStatusBit(var_array_bitmap, 0, 'Control_En')
    initStatusBit(var_array_bitmap, 1, 'Dir_V2g')
    initStatusBit(var_array_bitmap, 2, 'Calib_Ok')
    initStatusBit(var_array_bitmap, 3, 'Debug_En')
    initStatusBit(var_array_bitmap, 4, 'EOSS_LLC1')
    initStatusBit(var_array_bitmap, 5, 'EOSS_LLC2')
    initStatusBit(var_array_bitmap, 6, 'LLC2_En')
    initStatusBit(var_array_bitmap, 7, 'Pri_Halfbridge_En')
    initStatusBit(var_array_bitmap, 8, 'Config_Ok')
    initStatusBit(var_array_bitmap, 9, 'Debug_Fault_En')
    displayParamWrite(var_array_bitmap[0], var_array[3], 0, 0)
    displayParamWrite(var_array_bitmap[1], var_array[3], 1, 0)
    displayParamRead(var_array_bitmap[2], var_array[3], 2, 1)
    displayParamWrite(var_array_bitmap[3], var_array[3], 3, 0)
    displayParamRead(var_array_bitmap[4], var_array[3], 4, 1)
    displayParamRead(var_array_bitmap[5], var_array[3], 5, 1)
    displayParamWrite(var_array_bitmap[6], var_array[3], 6, 0)
    displayParamWrite(var_array_bitmap[7], var_array[3], 7, 0)
    displayParamRead(var_array_bitmap[8], var_array[3], 8, 1)
    displayParamWrite(var_array_bitmap[9], var_array[3], 9, 0)

    var_array[3].setLayout(var_array[3].layout)

    var_array[5].setWidget(var_array[3])
    var_array[5].setFloating(True)
    var_array[5].setHidden(True)
    #pb
    var_array[6] = QPushButton()
    var_array[6].setFixedWidth(40)
    var_array[6].setFixedHeight(15)
    var_array[6].setStyleSheet('background-color: #000075; color: white')
    var_array[6].setText(name)
    var_array[6].clicked.connect(lambda: actDock(var_array))
    #checkbox
    var_array[7] = QCheckBox()
    var_array[7].setFixedWidth(15)
    var_array[7].setFixedHeight(15)
    var_array[7].toggle()
    var_array[7].setChecked(False)
    var_array[7].stateChanged.connect(lambda: actCheckBox(var_array))

def initStatusFault(var_array, var_array_bitmap, name):
#write/read: func, value, watch, qwidget, label_value, dock, pb, checkbox    
    #label_value
    var_array[4] = QLabel('0')
    var_array[4].setFixedWidth(40)
    var_array[4].setFixedHeight(15)
    #dock
    var_array[5] = QDockWidget(name)
    var_array[5].setGeometry(0, 0, 200, 300)

    var_array[3] = QWidget()
    var_array[3].layout =  QGridLayout()

    initStatusBit(var_array_bitmap, 0, 'TZ')
    initStatusBit(var_array_bitmap, 1, 'Vout_OV')
    initStatusBit(var_array_bitmap, 2, 'Vbat_OV')
    initStatusBit(var_array_bitmap, 3, 'Vbulk_OV')
    initStatusBit(var_array_bitmap, 4, 'Vaux_UV')
    initStatusBit(var_array_bitmap, 5, 'LLC1_Sec_Idc_OC')
    initStatusBit(var_array_bitmap, 6, 'LLC2_Sec_Idc_OC')
    initStatusBit(var_array_bitmap, 7, 'LLC1_Pri_Idc_OC')
    initStatusBit(var_array_bitmap, 8, 'LLC2_Pri_Idc_OC')
    initStatusBit(var_array_bitmap, 9, 'LLC1_Temp_Sr_OT')
    initStatusBit(var_array_bitmap, 10, 'LLC2_Temp_Sr_OT')
    initStatusBit(var_array_bitmap, 11, 'Temp_Outlet_OT')
    displayParamRead(var_array_bitmap[0], var_array[3], 0, 0)
    displayParamRead(var_array_bitmap[1], var_array[3], 1, 0)
    displayParamRead(var_array_bitmap[2], var_array[3], 2, 0)
    displayParamRead(var_array_bitmap[3], var_array[3], 3, 0)
    displayParamRead(var_array_bitmap[4], var_array[3], 4, 0)
    displayParamRead(var_array_bitmap[5], var_array[3], 5, 0)
    displayParamRead(var_array_bitmap[6], var_array[3], 6, 0)
    displayParamRead(var_array_bitmap[7], var_array[3], 7, 0)
    displayParamRead(var_array_bitmap[8], var_array[3], 8, 0)
    displayParamRead(var_array_bitmap[9], var_array[3], 9, 0)
    displayParamRead(var_array_bitmap[10], var_array[3], 10, 0)
    displayParamRead(var_array_bitmap[11], var_array[3], 11, 0)

    var_array[3].setLayout(var_array[3].layout)

    var_array[5].setWidget(var_array[3])
    var_array[5].setFloating(True)
    var_array[5].setHidden(True)
    #pb
    var_array[6] = QPushButton()
    var_array[6].setFixedWidth(40)
    var_array[6].setFixedHeight(15)
    var_array[6].setStyleSheet('background-color: #000075; color: white')
    var_array[6].setText(name)
    var_array[6].clicked.connect(lambda: actDock(var_array))
    #checkbox
    var_array[7] = QCheckBox()
    var_array[7].setFixedWidth(15)
    var_array[7].setFixedHeight(15)
    var_array[7].toggle()
    var_array[7].setChecked(False)
    var_array[7].stateChanged.connect(lambda: actCheckBox(var_array))

def initStatusDigin(var_array, var_array_bitmap, name):
#write/read: func, value, watch, qwidget, label_value, dock, pb, checkbox    
    #label_value
    var_array[4] = QLabel('0')
    var_array[4].setFixedWidth(40)
    var_array[4].setFixedHeight(15)
    #dock
    var_array[5] = QDockWidget(name)
    var_array[5].setGeometry(0, 0, 200, 300)

    var_array[3] = QWidget()
    var_array[3].layout =  QGridLayout()

    initStatusBit(var_array_bitmap, 0, 'Can_Addr1')
    initStatusBit(var_array_bitmap, 1, 'Can_Addr2')
    initStatusBit(var_array_bitmap, 2, 'Can_Addr3')
    initStatusBit(var_array_bitmap, 3, 'Can_Addr4')
    initStatusBit(var_array_bitmap, 4, 'Pfc_Ok')
    initStatusBit(var_array_bitmap, 5, 'Ac_Ok')
    initStatusBit(var_array_bitmap, 6, 'DCDC_En')
    displayParamRead(var_array_bitmap[0], var_array[3], 0, 0)
    displayParamRead(var_array_bitmap[1], var_array[3], 1, 0)
    displayParamRead(var_array_bitmap[2], var_array[3], 2, 0)
    displayParamRead(var_array_bitmap[3], var_array[3], 3, 0)
    displayParamRead(var_array_bitmap[4], var_array[3], 4, 0)
    displayParamRead(var_array_bitmap[5], var_array[3], 5, 0)
    displayParamRead(var_array_bitmap[6], var_array[3], 6, 0)

    var_array[3].setLayout(var_array[3].layout)

    var_array[5].setWidget(var_array[3])
    var_array[5].setFloating(True)
    var_array[5].setHidden(True)
    #pb
    var_array[6] = QPushButton()
    var_array[6].setFixedWidth(40)
    var_array[6].setFixedHeight(15)
    var_array[6].setStyleSheet('background-color: #000075; color: white')
    var_array[6].setText(name)
    var_array[6].clicked.connect(lambda: actDock(var_array))
    #checkbox
    var_array[7] = QCheckBox()
    var_array[7].setFixedWidth(15)
    var_array[7].setFixedHeight(15)
    var_array[7].toggle()
    var_array[7].setChecked(False)
    var_array[7].stateChanged.connect(lambda: actCheckBox(var_array))

def initStatusDigout(var_array, var_array_bitmap, name):
#write/read: func, value, watch, qwidget, label_value, dock, pb, checkbox    
    #label_value
    var_array[4] = QLabel('0')
    var_array[4].setFixedWidth(40)
    var_array[4].setFixedHeight(15)
    #dock
    var_array[5] = QDockWidget(name)
    var_array[5].setGeometry(0, 0, 200, 300)

    var_array[3] = QWidget()
    var_array[3].layout =  QGridLayout()

    initStatusBit(var_array_bitmap, 0, 'LED_R')
    initStatusBit(var_array_bitmap, 1, 'LED_G')
    initStatusBit(var_array_bitmap, 2, 'LED_Y')
    initStatusBit(var_array_bitmap, 3, 'Dchg_Off')
    initStatusBit(var_array_bitmap, 4, 'Pfc_En')
    initStatusBit(var_array_bitmap, 5, 'Temp_Mux_S0')
    initStatusBit(var_array_bitmap, 6, 'Temp_Mux_S1')
    initStatusBit(var_array_bitmap, 7, 'Temp_Mux_S2')
    initStatusBit(var_array_bitmap, 8, 'Valve_En')
    initStatusBit(var_array_bitmap, 9, 'Relay_En')
    displayParamRead(var_array_bitmap[0], var_array[3], 0, 0)
    displayParamRead(var_array_bitmap[1], var_array[3], 1, 0)
    displayParamRead(var_array_bitmap[2], var_array[3], 2, 0)
    displayParamRead(var_array_bitmap[3], var_array[3], 3, 0)
    displayParamRead(var_array_bitmap[4], var_array[3], 4, 0)
    displayParamRead(var_array_bitmap[5], var_array[3], 5, 0)
    displayParamRead(var_array_bitmap[6], var_array[3], 6, 0)
    displayParamRead(var_array_bitmap[7], var_array[3], 7, 0)
    displayParamRead(var_array_bitmap[8], var_array[3], 8, 0)
    displayParamRead(var_array_bitmap[9], var_array[3], 9, 0)

    var_array[3].setLayout(var_array[3].layout)

    var_array[5].setWidget(var_array[3])
    var_array[5].setFloating(True)
    var_array[5].setHidden(True)
    #pb
    var_array[6] = QPushButton()
    var_array[6].setFixedWidth(40)
    var_array[6].setFixedHeight(15)
    var_array[6].setStyleSheet('background-color: #000075; color: white')
    var_array[6].setText(name)
    var_array[6].clicked.connect(lambda: actDock(var_array))
    #checkbox
    var_array[7] = QCheckBox()
    var_array[7].setFixedWidth(15)
    var_array[7].setFixedHeight(15)
    var_array[7].toggle()
    var_array[7].setChecked(False)
    var_array[7].stateChanged.connect(lambda: actCheckBox(var_array))

def initParamStatusAll():
    initParam(state_control, 'Control')
    initParam(state_calib, 'Calibration')
    initParam(state_hkeep, 'Housekeeping') 

    initStatusControl(status_control, status_control_bitmap, 'Control')
    initStatusFault(status_fault, status_fault_bitmap, 'Fault')
    initStatusDigin(status_digin, status_digin_bitmap, 'Digin')
    initStatusDigout(status_digout, status_digout_bitmap, 'Digout')

    initParam(llc1_sec_idc, 'LLC1 Sec Idc')           
    initParam(llc1_pri_idc, 'LLC1 Pri Idc')             
    initParam(vout, 'Vout')             
    initParam(vbat, 'Vbat')              
    initParam(vaux, 'Vaux')        
    initParam(vbulk, 'Vbulk')
    initParam(llc2_pri_idc, 'LLC2 Pri Idc')
    initParam(llc2_sec_idc, 'LLC2 Sec Idc')
    initParam(llc1_temp_sr, 'LLC1 Temp Sr')
    initParam(llc2_temp_sr, 'LLC2 Temp Sr')
    initParam(temp_outlet, 'Temp Outlet')
    initParam(gain_vout, 'Gain Vout')
    initParam(offset_vout, 'Offset Vout')
    initParam(gain_vbat, 'Gain Vbat')
    initParam(offset_vbat, 'Offset Vbat')
    initParam(gain_vbulk, 'Gain Vbulk')
    initParam(offset_vbulk, 'Offset Vbulk')
    initParam(gain_llc1_sec_idc, 'Gain LLC1 Sec Idc')
    initParam(offset_llc1_sec_idc, 'Offset LLC1 Sec Idc')
    initParam(ref_vbat, 'Ref Vbat')
    initParam(ref_vbat_calib, 'Ref Vbat Calib')
    initParam(ref_iout, 'Ref Iout')
    initParam(ref_iout_calib, 'Ref Iout Calib')
    initParam(ref_iout_llc1_calib, 'Ref Iout LLC1 Calib')   
    initParam(ref_iout_llc2_calib, 'Ref Iout LLC2 Calib')
    initParam(ref_vbulk_calib, 'Ref Vbulk Calib')
    initParam(ref_vbulk_llc1_calib, 'Ref Vbulk LLC1 Calib')
    initParam(ref_vbulk_llc2_calib, 'Ref Vbulk LLC2 Calib') 
    initParam(ref_pout, 'Ref Pout')
    initParam(llc1_ts_tbctr, 'LLC1 Ts Tbctr')
    initParam(llc1_ps, 'LLC1 Ps')
    initParam(llc1_burstduty, 'LLC1 Burstduty') 
    initParam(llc2_ts_tbctr, 'LLC2 Ts Tbctr')
    initParam(llc2_ps, 'LLC2 Ps')
    initParam(llc2_burstduty, 'LLC2 Burstduty')
    initParam(pfm_kp, 'Pfm Kp')
    initParam(pfm_ki, 'Pfm Ki')
    initParam(pfm_integ_max, 'Pfm Integ Max')
    initParam(pfm_integ_min, 'Pfm Integ Min')
    initParam(pspwm_kp, 'Pspwm Kp')   
    initParam(pspwm_ki, 'Pspwm Ki')
    initParam(pspwm_integ_max, 'Pspwm Integ Max')
    initParam(pspwm_integ_min, 'Pspwm Integ Min')
    initParam(burstduty_kp, 'Burstduty Kp') 
    initParam(burstduty_ki, 'Burstduty Ki')
    initParam(burstduty_integ_max, 'Burstduty Integ Max')
    initParam(burstduty_integ_min, 'Burstduty Integ Min')
    initParam(vdroop_kp, 'Vdroop Kp') 
    initParam(vdroop_ki, 'Vdroop Ki')
    initParam(vdroop_integ_max, 'Vdroop Integ Max')
    initParam(vdroop_integ_min, 'Vdroop Integ Min')

    initParam(version, 'Version')
    initParam(runtime_adca1, 'Runtime Adca1')
    initParam(runtime_adcb1, 'Runtime Adcb1')
    initParam(runtime_control, 'Runtime Control')
    initParam(runtime_idle, 'Runtime Idle')
    initParam(llc1_ts_tbctr_buffer, 'LLC1 Ts Tbctr')
    initParam(llc1_ps_buffer, 'LLC1 Ps')
    initParam(llc1_burstduty_buffer, 'LLC1 Burstduty')
    initParam(llc2_ts_tbctr_buffer, 'LLC2 Ts Tbctr')
    initParam(llc2_ps_buffer, 'LLC2 Ps')
    initParam(llc2_burstduty_buffer, 'LLC2 Burstduty')

def displayParamRead(var_array, obj, posx, posy):
    #checkbox, label, label_value 
    #checkbox
    obj.layout.addWidget(var_array[7], posx, posy)
    #label
    obj.layout.addWidget(var_array[3], posx, posy+1)
    #label_value
    obj.layout.addWidget(var_array[4], posx, posy+2)

def displayParamWrite(var_array, obj, posx, posy):
    #lineedit, pb, label, label_value
    #lineedit
    obj.layout.addWidget(var_array[5], posx, posy)
    #pb
    obj.layout.addWidget(var_array[6], posx, posy+1)
    #label
    obj.layout.addWidget(var_array[3], posx, posy+2)
    #label_value
    obj.layout.addWidget(var_array[4], posx, posy+3)

def displayStatusRead(var_array, obj, posx, posy):
    #checkbox, pb, label_value 
    #checkbox
    obj.layout.addWidget(var_array[7], posx, posy)
    #pb
    obj.layout.addWidget(var_array[6], posx, posy+1)
    #label_value
    obj.layout.addWidget(var_array[4], posx, posy+2)

def displayStatusWrite(var_array, obj, posx, posy):
    #checkbox, pb, label_value 
    #checkbox
    obj.layout.addWidget(var_array[7], posx, posy)
    #pb
    obj.layout.addWidget(var_array[6], posx, posy+1)
    #label_value
    obj.layout.addWidget(var_array[4], posx, posy+2)

def updateGuiStatusControl(count_x):
    for i in range(16):
        status_control_bitmap[i][4].setText(str(    bin( (status_control[1]>>i) & 0b1 )       ))

def updateGuiStatusFault(count_x):
    for i in range(16):
        status_fault_bitmap[i][4].setText(str(    bin( (status_fault[1]>>i) & 0b1 )       ))

def updateGuiStatusDigin(count_x):
    for i in range(16):
        status_digin_bitmap[i][4].setText(str(    bin( (status_digin[1]>>i) & 0b1 )       ))

def updateGuiStatusDigout(count_x):
    for i in range(16):
        status_digout_bitmap[i][4].setText(str(    bin( (status_digout[1]>>i) & 0b1 )       ))

bool_listen_en = 0
def threadUpdateGUI():
    count_x = 0
    
    while True:
        if(getCanListenEn()): #todo, make label_value consistent. e.g. element3
            [func, value] = updateFuncTable()
            
            count_x += 1
            if(count_x > (getSizeFuncTable() - 2)):
                count_x = 0

            #count_x = 26
            
            try:
                #func_table[0x300][4].setText( str(getCanDataRxValue(func_table[0x300][0])) )
                #count_x = 20
                list(func_table.values())[count_x][4].setText(str(    getCanDataRxValue(list(func_table.keys())[count_x])    ))
                if(list(func_table.keys())[count_x] == 0x0100): #status_control
                    updateGuiStatusControl(count_x)
                elif(list(func_table.keys())[count_x] == 0x0101): #status_fault
                    updateGuiStatusFault(count_x)
                elif(list(func_table.keys())[count_x] == 0x0102): #status_digin
                    updateGuiStatusDigin(count_x)
                elif(list(func_table.keys())[count_x] == 0x0103): #status_digout
                    updateGuiStatusDigout(count_x)
            except:
                pass
        else: 
            time.sleep(0.1)

class window(QMainWindow):    
    def __init__(self):
        super().__init__()
        #self.setGeometry(30, 60, 650, 650) #test only

        self.setGeometry(30, 60, 1305, 645) #(posx, posy, sizex, sizey)
        self.setStyleSheet('background-color: #ebebf2') #454647
        self.setWindowTitle('Bidirectional EV Charger GUI v0.19')
        self.uiComms()

        initParamStatusAll()
        
        self.control = uiControl(self)
        self.control.setGeometry(10, 45, 645, 290)

        self.plot = uiPlot(self) #displayDiagAnalysis(self)
        self.plot.setGeometry(652, 45, 655, 280)

        self.diagnostics_acdc = uiDiagnosticsAcdc(self)
        self.diagnostics_acdc.setGeometry(20, 340, 624, 290)

        self.diagnostics_dcdc = uiDiagnosticsDcdc(self)
        self.diagnostics_dcdc.setGeometry(660, 340, 624, 290)
                
        self.show()

    def uiComms(self):
        #Initiate combobox for serial com port
        self.labelComPort = QLabel(self)
        self.labelComPort.setText('Select device:')
        self.labelComPort.move(20, 1)
        
        self.comboboxComPort = QComboBox(self)
        self.list_com_port = []
        self.fillListComPort()
        self.comboboxComPort.addItems(self.list_com_port)
        self.comboboxComPort.move(20, 25)
        self.comboboxComPort.resize(243, 20)
        #self.comboboxComPort.adjustSize()
        self.pbListen = QPushButton(self)
        self.pbListen.setStyleSheet('background-color: #000075; color: white')
        self.pbListen.setText('Listen')
        self.pbListen.resize(75, 18)
        self.pbListen.move(270, 25)
        self.pbListen.clicked.connect(self.updatePbListen)

        #Set action for combobox click
        self.comboboxComPort.activated[str].connect(self.actSelectComPort)

    def fillListComPort(self):
        for x in serial.tools.list_ports.comports():
            self.list_com_port.append(str(x))

    def actSelectComPort(self, text):
        com_port = text.rpartition(')')[0].partition('(')[-1]
        print(com_port) #todo: select com port
        #initCanBus(com_port)

    def updatePbListen(self):
        if(getCanListenEn()):
            setCanListenEn(0)
            self.pbListen.setStyleSheet('background-color: #000075; color: white')
        else:
            setCanListenEn(1)
            #processWriteMsg(0x401, 0x6969)
            self.pbListen.setStyleSheet('background-color: white; color: #000075')

class uiControl(QWidget): 
    def __init__(self, parent): 
        super().__init__(parent) 
        self.layout = QVBoxLayout(self)
        self.setStyleSheet('background-color: white')
  
        #Initialize tab screen 
        self.tabs = QTabWidget() 
        self.tab1 = QWidget() 
        self.tab2 = QWidget() 
  
        #Add tabs 
        self.tabs.addTab(self.tab1, 'Closed loop') 
        self.tabs.addTab(self.tab2, 'Open loop') 

        #Init tabs
        self.initControlTab1(self.tab1)
        self.initControlTab2(self.tab2)
  
        #Add tabs to custom widget 
        self.layout.addWidget(self.tabs) 
        self.setLayout(self.layout)

    def initControlTab1(self, tab):
        self.setStyleSheet('background-color: white')
        #Create first tab
        tab.layout = QGridLayout(self)
        
        #Init widget
        #parameters are initiated in initParamAll()

        #Show and position widget
        #displayParamWrite(status_charger_control, self.tab1, 0, 0)
        displayParamWrite(ref_vbat, self.tab1, 0, 0)
        displayParamWrite(ref_iout, self.tab1, 1, 0)
        displayParamRead(ref_pout, self.tab1, 2, 1)
        displayParamRead(llc1_ts_tbctr, self.tab1, 3, 1)
        displayParamRead(llc1_ps, self.tab1, 4, 1)
        displayParamRead(llc1_burstduty, self.tab1, 5, 1)
        displayParamRead(llc2_ts_tbctr, self.tab1, 6, 1)
        displayParamRead(llc2_ps, self.tab1, 7, 1)
        displayParamRead(llc2_burstduty, self.tab1, 8, 1)

        displayParamRead(pfm_kp, self.tab1, 0, 5)
        displayParamRead(pfm_ki, self.tab1, 1, 5)
        displayParamRead(pfm_integ_max, self.tab1, 2, 5)
        displayParamRead(pfm_integ_min, self.tab1, 3, 5)
        displayParamRead(pspwm_kp, self.tab1, 4, 5)
        displayParamRead(pspwm_ki, self.tab1, 5, 5)
        displayParamRead(pspwm_integ_max, self.tab1, 6, 5)
        displayParamRead(pspwm_integ_min, self.tab1, 7, 5)
        displayParamRead(burstduty_kp, self.tab1, 8, 5)

        displayParamRead(burstduty_ki, self.tab1, 0, 9)
        displayParamRead(burstduty_integ_max, self.tab1, 1, 9)
        displayParamRead(burstduty_integ_min, self.tab1, 2, 9)
        displayParamRead(vdroop_kp, self.tab1, 3, 9)
        displayParamRead(vdroop_ki, self.tab1, 4, 9)
        displayParamRead(vdroop_integ_max, self.tab1, 5, 9)
        displayParamRead(vdroop_integ_min, self.tab1, 6, 9)
        
        tab.setLayout(tab.layout)

    def initControlTab2(self, tab):
        self.setStyleSheet('background-color: white')
        #Create first tab
        tab.layout = QGridLayout(self)
        
        #Init widget
        #parameters are initiated in initParamAll() 
        
        #Show and position widget
        displayParamWrite(llc1_ts_tbctr_buffer, self.tab2, 0, 0) #todo: not displaying
        displayParamWrite(llc1_ps_buffer, self.tab2 ,1 ,0)
        displayParamWrite(llc1_burstduty_buffer, self.tab2, 2, 0)
        displayParamWrite(llc2_ts_tbctr_buffer, self.tab2, 3, 0)
        displayParamWrite(llc2_ps_buffer, self.tab2, 4 , 0)
        displayParamWrite(llc2_burstduty_buffer, self.tab2, 5 , 0)
        
        tab.setLayout(tab.layout)

class uiDiagnosticsAcdc(QFrame):
    #todo: add title, add frame
    def __init__(self, parent): 
        super().__init__(parent)
        self.setStyleSheet('background-color: white') # #000075')

        #Init layout
        self.layout = QGridLayout()

        #Init widget
        self.label_title =  QLabel('AC-DC')
        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setFixedHeight(15)

        #Show and position widget
        self.layout.addWidget(self.label_title,            0, 0, 1, 9)

        self.setLayout(self.layout)

class uiDiagnosticsDcdc(QFrame):
    #todo: add title, add frame
    def __init__(self, parent): 
        super().__init__(parent)
        self.setStyleSheet('background-color: white')

        #Init layout
        self.layout =  QGridLayout()

        #Init widget
        self.label_title =  QLabel('DC-DC')
        self.label_states =  QLabel('State')
        self.label_status =  QLabel('Status')
        self.label_adcs =  QLabel('ADC')
        self.label_calib =  QLabel('Calibration')
        self.label_info =  QLabel('Info')

        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setFixedHeight(15)
        self.label_states.setFixedHeight(15)
        self.label_status.setFixedHeight(15)
        self.label_adcs.setFixedHeight(15)
        #parameters are initiated in initParamAll() 

        #Show and position widget
        self.layout.addWidget(self.label_title,            0, 0, 0, 12)
        
        self.layout.addWidget(self.label_states,           1, 0)        
        displayParamRead(state_control, self, 2, 0)
        displayParamRead(state_calib, self, 3, 0)
        displayParamRead(state_hkeep, self, 4, 0)
        
        self.layout.addWidget(self.label_status,           5, 0)
        displayStatusWrite(status_control, self, 6, 0)
        displayStatusRead(status_fault, self, 7, 0)
        displayStatusRead(status_digin, self, 8, 0)
        displayStatusRead(status_digout, self, 9, 0)

        self.layout.addWidget(self.label_adcs,             10, 0)
        displayParamRead(vbat, self, 11, 0)
        displayParamRead(vout, self ,12 ,0)
        displayParamRead(vbulk, self ,1 ,4)
        displayParamRead(vaux, self ,2 ,4)
        displayParamRead(llc1_sec_idc, self, 3, 4)
        displayParamRead(llc2_sec_idc, self, 4, 4)
        displayParamRead(llc1_pri_idc, self, 5, 4)
        displayParamRead(llc2_pri_idc, self, 6, 4)
        displayParamRead(llc1_temp_sr, self, 7, 4)
        displayParamRead(llc2_temp_sr, self, 8, 4)
        displayParamRead(temp_outlet, self, 9, 4)

        self.layout.addWidget(self.label_calib,             10, 4)
        displayParamRead(gain_vout, self, 11, 4)
        displayParamRead(offset_vout, self, 12, 4)
        displayParamRead(gain_vbat, self, 1, 8)
        displayParamRead(offset_vbat, self, 2, 8)
        displayParamRead(gain_vbulk, self, 3, 8)
        displayParamRead(offset_vbulk, self, 4, 8)
        displayParamRead(gain_llc1_sec_idc, self, 5, 8)
        displayParamRead(offset_llc1_sec_idc, self, 6, 8)

        self.layout.addWidget(self.label_info,             7, 8)
        displayParamRead(version, self, 8, 8)

        self.setLayout(self.layout)

class Communicate(QObject):
    data_signal = pyqtSignal(float)

def dataSendLoop(addData_callbackFunc): #todo: remove all global
    # Setup the signal-slot mechanism.
    mySrc = Communicate()
    mySrc.data_signal.connect(addData_callbackFunc)

    # Simulate some data
    num = 10
    n = np.ones(num) #np.linspace(0, 9, 10)    
    y = 0 #y = 50 + 25*(np.sin(n / 8.3)) + 10*(np.sin(n / 7.5)) - 5*(np.sin(n / 1.5))
    i = 0

    while(True):
        value = getCanDataRxValue(watch_func)
        y = n*value

        if(i > (num - 2)):
            i = 0
        time.sleep(0.001)
        mySrc.data_signal.emit(y[i]) # <- Here you emit a signal!
        i += 1

if __name__ == '__main__':
    app = QApplication(sys.argv)
    root = window()
    
    #logging.basicConfig(format=format, level=logging.INFO, datefmt='%H:%M:%S')
    #logging.info('Main    : before creating listen thread')

    thread_update_gui = threading.Thread(target=threadUpdateGUI)
    thread_update_gui.start()

    thread_can_listen = threading.Thread(target=threadListenCan)
    thread_can_listen.start()
    setCanListenEn(0)

    # Add the callbackfunc to ..
    myDataLoop = threading.Thread(name = 'myDataLoop', target = dataSendLoop, daemon = True, args = (root.plot.addData_callbackFunc,))
    myDataLoop.start()

    #print('func_table: ', func_table)
        
    sys.exit(app.exec_())